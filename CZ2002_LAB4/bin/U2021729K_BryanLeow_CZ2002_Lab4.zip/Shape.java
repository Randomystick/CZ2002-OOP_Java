public interface Shape
{
	public double area();
}
